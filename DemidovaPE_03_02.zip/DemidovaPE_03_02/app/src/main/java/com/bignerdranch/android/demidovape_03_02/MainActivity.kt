package com.bignerdranch.android.demidovape_03_02

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

lateinit var login : EditText
lateinit var password : EditText
lateinit var registration : Button
lateinit var SharedPreferences : SharedPreferences

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        login = findViewById(R.id.login)
        password = findViewById(R.id.password)
        registration = findViewById(R.id.buttonLogin)
        SharedPreferences = getSharedPreferences("SETTINGS", Context.MODE_PRIVATE)
        val editor = SharedPreferences.edit()

        val saveLogin = SharedPreferences.getString("login", "")
        val savePassword = SharedPreferences.getString("password", "")

        registration.setOnClickListener {
            val Intent = Intent(this, CalculatorActivity::class.java)

            if(login.text.toString() != "" && password.text.toString() != "")
            {
                editor.putString("login", login.text.toString())
                editor.putString("password", password.text.toString())
                editor.apply()
                startActivity(intent)
            }

            else
            {
                Toast.makeText(this, "Введите значения!", Toast.LENGTH_SHORT).show()
            }

        }

    }
}