package com.bignerdranch.android.demidovape_03_02

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner

lateinit var spinner: Spinner
lateinit var countMetres: EditText
lateinit var buttonCalc: Button

class CalculatorActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calculator)

        countMetres = findViewById(R.id.metres)

        val list : MutableList<String> = mutableListOf("1. 1-комнатная квартира", "2. 2-комнатная квартира", "3. 3-комнатная квартира", "4. Студия")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, list)

        spinner.adapter = adapter

        val Intent = Intent(this, CalculatorActivity::class.java)

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long)
            {
                if(spinner.selectedItemPosition == 0){

                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?)
            {

            }

        }


    }
}